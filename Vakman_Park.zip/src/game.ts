const scene = new Entity()
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
scene.addComponentOrReplace(transform)
engine.addEntity(scene)

const floorFantasyRocks_04 = new Entity()
floorFantasyRocks_04.setParent(scene)
const gltfShape = new GLTFShape('models/FloorFantasyRocks_04/FloorFantasyRocks_04.glb')
floorFantasyRocks_04.addComponentOrReplace(gltfShape)
const transform_2 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
floorFantasyRocks_04.addComponentOrReplace(transform_2)
engine.addEntity(floorFantasyRocks_04)

const stalagmite_03 = new Entity()
stalagmite_03.setParent(scene)
const gltfShape_2 = new GLTFShape('models/Stalagmite_03/Stalagmite_03.glb')
stalagmite_03.addComponentOrReplace(gltfShape_2)
const transform_3 = new Transform({
  position: new Vector3(8.5, 0, 6.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stalagmite_03.addComponentOrReplace(transform_3)
engine.addEntity(stalagmite_03)

const stalagmite_03_2 = new Entity()
stalagmite_03_2.setParent(scene)
stalagmite_03_2.addComponentOrReplace(gltfShape_2)
const transform_4 = new Transform({
  position: new Vector3(11, 0, 7.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stalagmite_03_2.addComponentOrReplace(transform_4)
engine.addEntity(stalagmite_03_2)

const stalagmite_03_3 = new Entity()
stalagmite_03_3.setParent(scene)
stalagmite_03_3.addComponentOrReplace(gltfShape_2)
const transform_5 = new Transform({
  position: new Vector3(8.5, 0, 9),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stalagmite_03_3.addComponentOrReplace(transform_5)
engine.addEntity(stalagmite_03_3)

const tree_Leafs_03 = new Entity()
tree_Leafs_03.setParent(scene)
const gltfShape_3 = new GLTFShape('models/Tree_Leafs_03/Tree_Leafs_03.glb')
tree_Leafs_03.addComponentOrReplace(gltfShape_3)
const transform_6 = new Transform({
  position: new Vector3(3.5, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
tree_Leafs_03.addComponentOrReplace(transform_6)
engine.addEntity(tree_Leafs_03)

const pond_Stone_01 = new Entity()
pond_Stone_01.setParent(scene)
const gltfShape_4 = new GLTFShape('models/Pond_Stone_01/Pond_Stone_01.glb')
pond_Stone_01.addComponentOrReplace(gltfShape_4)
const transform_7 = new Transform({
  position: new Vector3(1.5, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
pond_Stone_01.addComponentOrReplace(transform_7)
engine.addEntity(pond_Stone_01)

const pond_Stone_01_2 = new Entity()
pond_Stone_01_2.setParent(scene)
pond_Stone_01_2.addComponentOrReplace(gltfShape_4)
const transform_8 = new Transform({
  position: new Vector3(6, 0, 13),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
pond_Stone_01_2.addComponentOrReplace(transform_8)
engine.addEntity(pond_Stone_01_2)

const mushrooms_04 = new Entity()
mushrooms_04.setParent(scene)
const gltfShape_5 = new GLTFShape('models/Mushrooms_04/Mushrooms_04.glb')
mushrooms_04.addComponentOrReplace(gltfShape_5)
const transform_9 = new Transform({
  position: new Vector3(3, 0, 11),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
mushrooms_04.addComponentOrReplace(transform_9)
engine.addEntity(mushrooms_04)

const mushrooms_04_2 = new Entity()
mushrooms_04_2.setParent(scene)
mushrooms_04_2.addComponentOrReplace(gltfShape_5)
const transform_10 = new Transform({
  position: new Vector3(3.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
mushrooms_04_2.addComponentOrReplace(transform_10)
engine.addEntity(mushrooms_04_2)

const mushrooms_04_3 = new Entity()
mushrooms_04_3.setParent(scene)
mushrooms_04_3.addComponentOrReplace(gltfShape_5)
const transform_11 = new Transform({
  position: new Vector3(4.5, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
mushrooms_04_3.addComponentOrReplace(transform_11)
engine.addEntity(mushrooms_04_3)

const vegetation_06 = new Entity()
vegetation_06.setParent(scene)
const gltfShape_6 = new GLTFShape('models/Vegetation_06/Vegetation_06.glb')
vegetation_06.addComponentOrReplace(gltfShape_6)
const transform_12 = new Transform({
  position: new Vector3(7.5, 0, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
vegetation_06.addComponentOrReplace(transform_12)
engine.addEntity(vegetation_06)

const vegetation_06_2 = new Entity()
vegetation_06_2.setParent(scene)
vegetation_06_2.addComponentOrReplace(gltfShape_6)
const transform_13 = new Transform({
  position: new Vector3(1.5, 0, 7.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
vegetation_06_2.addComponentOrReplace(transform_13)
engine.addEntity(vegetation_06_2)

const ornament_Stone_01 = new Entity()
ornament_Stone_01.setParent(scene)
const gltfShape_7 = new GLTFShape('models/Ornament_Stone_01/Ornament_Stone_01.glb')
ornament_Stone_01.addComponentOrReplace(gltfShape_7)
const transform_14 = new Transform({
  position: new Vector3(9.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ornament_Stone_01.addComponentOrReplace(transform_14)
engine.addEntity(ornament_Stone_01)

const writenStone_01 = new Entity()
writenStone_01.setParent(scene)
const gltfShape_8 = new GLTFShape('models/WritenStone_01/WritenStone_01.glb')
writenStone_01.addComponentOrReplace(gltfShape_8)
const transform_15 = new Transform({
  position: new Vector3(7.5, 0, 7.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
writenStone_01.addComponentOrReplace(transform_15)
engine.addEntity(writenStone_01)

const writenStone_01_2 = new Entity()
writenStone_01_2.setParent(scene)
writenStone_01_2.addComponentOrReplace(gltfShape_8)
const transform_16 = new Transform({
  position: new Vector3(10, 0, 6),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
writenStone_01_2.addComponentOrReplace(transform_16)
engine.addEntity(writenStone_01_2)

const writenStone_01_3 = new Entity()
writenStone_01_3.setParent(scene)
writenStone_01_3.addComponentOrReplace(gltfShape_8)
const transform_17 = new Transform({
  position: new Vector3(10.5, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
writenStone_01_3.addComponentOrReplace(transform_17)
engine.addEntity(writenStone_01_3)

const stone_Magic_01 = new Entity()
stone_Magic_01.setParent(scene)
const gltfShape_9 = new GLTFShape('models/Stone_Magic_01/Stone_Magic_01.glb')
stone_Magic_01.addComponentOrReplace(gltfShape_9)
const transform_18 = new Transform({
  position: new Vector3(14.5, 0, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stone_Magic_01.addComponentOrReplace(transform_18)
engine.addEntity(stone_Magic_01)

const stone_Magic_01_2 = new Entity()
stone_Magic_01_2.setParent(scene)
stone_Magic_01_2.addComponentOrReplace(gltfShape_9)
const transform_19 = new Transform({
  position: new Vector3(14.5, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stone_Magic_01_2.addComponentOrReplace(transform_19)
engine.addEntity(stone_Magic_01_2)

const stone_Magic_01_3 = new Entity()
stone_Magic_01_3.setParent(scene)
stone_Magic_01_3.addComponentOrReplace(gltfShape_9)
const transform_20 = new Transform({
  position: new Vector3(1.5, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stone_Magic_01_3.addComponentOrReplace(transform_20)
engine.addEntity(stone_Magic_01_3)

const stone_Magic_02 = new Entity()
stone_Magic_02.setParent(scene)
const gltfShape_10 = new GLTFShape('models/Stone_Magic_02/Stone_Magic_02.glb')
stone_Magic_02.addComponentOrReplace(gltfShape_10)
const transform_21 = new Transform({
  position: new Vector3(8, 0, 3),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stone_Magic_02.addComponentOrReplace(transform_21)
engine.addEntity(stone_Magic_02)

const stone_Magic_01_4 = new Entity()
stone_Magic_01_4.setParent(scene)
stone_Magic_01_4.addComponentOrReplace(gltfShape_9)
const transform_22 = new Transform({
  position: new Vector3(1.5, 0, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stone_Magic_01_4.addComponentOrReplace(transform_22)
engine.addEntity(stone_Magic_01_4)